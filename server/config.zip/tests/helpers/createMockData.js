import mongoose from 'mongoose';

export const createMockItem = (overrides = {}) => {
  return {
    name: 'item',
    quantity: 5,
    packed: true,
    category: new mongoose.Types.ObjectId(),
    ...overrides,
  };
};

export const createMockCategory = (overrides = {}) => {
  return {
    name: 'category',
    items: [],
    packingList: new mongoose.Types.ObjectId(),
    ...overrides,
  };
};

export const createMockPackingList = (overrides = {}) => {
  return {
    name: 'packingList',
    categories: [],
    user: new mongoose.Types.ObjectId(),
    startDate: Date.now(),
    endDate: Date.now(),
    destination: '',
    description: '',
    status: 'active',
    ...overrides,
  };
};

export const createMockUser = (overrides = {}) => {
  return {
    username: 'test',
    email: 'jest_test@gmail.com',
    password: 'testing1!',
    packingLists: [],
    ...overrides,
  };
};

export const createObjectId = () => {
  return new mongoose.Types.ObjectId();
};
